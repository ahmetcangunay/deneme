# Author: Ahmet Can GÜNAY
# coding=utf-8
# Copyright SAKURAI SYZ Team.
# Licensed under the MIT License, (the "License");
# you may not use this file except in compliance with the License.
# Lint as: python3

"""Introduction to the NER Dataset: Turkish Named Entity Recognition"""

import os

import datasets


logger = datasets.logging.get_logger(__name__)


_CITATION = """\
@author = "Ahmet Can GÜNAY, Arda TEKİN, Boran TOKTAY
"""

_DESCRIPTION = """\
The shared task of Turkish language-independent named entity recognition. We will concentrate on
four types of named entities: ANATOMY, OBSERVATION-PRESENT, OBSERVATION-ABSENT, OBSERVATION-UNCERTAIN and IMPRESSION.

The chunk tags and the named entity tags have the format I-TYPE which means that the word is inside a phrase of type TYPE. Only
if two phrases of the same type immediately follow each other, the first word of the second phrase will have tag
B-TYPE to show that it starts a new phrase. A word with tag O is not part of a phrase. Note the dataset uses IOB2
tagging scheme, whereas the original dataset uses IOB1.
"""

_TRAINING_FILE = "train.txt"
_DEV_FILE = "valid.txt"
_TEST_FILE = "test.txt"


class NerConfig(datasets.BuilderConfig):
    """BuilderConfig for Turkish NER"""

    def __init__(self, **kwargs):
        """BuilderConfig NERLLM.

        Args:
          **kwargs: keyword arguments forwarded to super.
        """
        super(NerConfig, self).__init__(**kwargs)


class NER(datasets.GeneratorBasedBuilder):
    """Turkish NER dataset."""

    BUILDER_CONFIGS = [
        NerConfig(name="Turkish-NER", version=datasets.Version(
            "1.0.0"), description="NER dataset"),
    ]

    def _info(self):
        return datasets.DatasetInfo(
            description=_DESCRIPTION,
            features=datasets.Features(
                {
                    "id": datasets.Value("string"),
                    "tokens": datasets.Sequence(datasets.Value("string")),
                    "ner_tags": datasets.Sequence(
                        datasets.features.ClassLabel(
                            names=[
                                "O",
                                "B-ANAT",
                                "I-ANAT",
                                "B-OBS-PRESENT",
                                "I-OBS-PRESENT",
                                "B-OBS-ABSENT",
                                "I-OBS-ABSENT",
                                "B-OBS-UNCERTAIN",
                                "I-OBS-UNCERTAIN",
                                "B-IMPRESSION",
                                "I-IMPRESSION"
                            ]
                        )
                    ),
                }
            ),
            supervised_keys=None,
            citation=_CITATION,
        )

    def _split_generators(self):
        """Returns SplitGenerators."""
        downloaded_file = "/home/ahmet/Desktop/ner/dataset"
        data_files = {
            "train": os.path.join(downloaded_file, _TRAINING_FILE),
            "dev": os.path.join(downloaded_file, _DEV_FILE),
            "test": os.path.join(downloaded_file, _TEST_FILE),
        }

        return [
            datasets.SplitGenerator(name=datasets.Split.TRAIN, gen_kwargs={
                                    "filepath": data_files["train"]}),
            datasets.SplitGenerator(name=datasets.Split.VALIDATION, gen_kwargs={
                                    "filepath": data_files["dev"]}),
            datasets.SplitGenerator(name=datasets.Split.TEST, gen_kwargs={
                                    "filepath": data_files["test"]}),
        ]

    def _generate_examples(self, filepath):
        logger.info("⏳ Generating examples from = %s", filepath)
        with open(filepath, encoding="utf-8") as f:
            guid = 0
            tokens = []
            ner_tags = []
            for line in f:
                if line.startswith("-DOCSTART-") or line == "" or line == "\n":
                    if tokens:
                        yield guid, {
                            "id": str(guid),
                            "tokens": tokens,
                            "ner_tags": ner_tags,
                        }
                        guid += 1
                        tokens = []
                        ner_tags = []
                else:
                    # NER tokens are space separated
                    splits = line.split(" ")
                    tokens.append(splits[0])
                    ner_tags.append(splits[1].rstrip())
            # last example
            if tokens:
                yield guid, {
                    "id": str(guid),
                    "tokens": tokens,
                    "ner_tags": ner_tags,
                }

